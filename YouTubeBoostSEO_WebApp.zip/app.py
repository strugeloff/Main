from flask import Flask, request, render_template
from youtube_transcript_api import YouTubeTranscriptApi
from urllib.parse import urlparse, parse_qs

app = Flask(__name__)

def get_video_id(url):
    parsed = urlparse(url)
    if parsed.hostname == 'youtu.be':
        return parsed.path[1:]
    elif parsed.hostname in ['www.youtube.com', 'youtube.com']:
        return parse_qs(parsed.query).get('v', [None])[0]
    return None

def extract_keywords(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        full_text = " ".join([t['text'] for t in transcript])
        words = full_text.lower().split()
        stopwords = ['the', 'and', 'is', 'to', 'in', 'you', 'a', 'of', 'yang', 'untuk', 'dengan']
        keywords = [word for word in words if word not in stopwords and len(word) > 3]
        freq = {}
        for word in keywords:
            freq[word] = freq.get(word, 0) + 1
        return sorted(freq, key=freq.get, reverse=True)[:10]
    except:
        return ["Gagal mengambil transkrip."]

@app.route('/', methods=['GET'])
def index():
    return render_template("index.html")

@app.route('/analyze', methods=['POST'])
def analyze():
    youtube_url = request.form['youtube_url']
    video_id = get_video_id(youtube_url)
    if not video_id:
        return render_template("index.html", keywords=["Link YouTube tidak valid."])
    keywords = extract_keywords(video_id)
    return render_template("index.html", keywords=keywords)

if __name__ == "__main__":
    app.run(debug=True)